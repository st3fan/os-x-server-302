#ifndef COMMON_H
#define COMMON_H

#include "lib.h"

extern struct connect_limit *connect_limit;
extern struct penalty *penalty;
extern bool anvil_restarted;

#endif
