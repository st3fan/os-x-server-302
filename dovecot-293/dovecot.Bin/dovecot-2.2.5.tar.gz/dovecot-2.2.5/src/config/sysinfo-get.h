#ifndef SYSINFO_GET_H
#define SYSINFO_GET_H

const char *sysinfo_get(const char *mail_location);

#endif
